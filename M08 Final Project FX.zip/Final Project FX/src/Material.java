public class Material {
	
	//Fields
	private String StoreName;
	private String StoreLocation;
	private String JobName;
	private String MaterialDescription;
	private Integer MaterialQuantity;
	private double MaterialCost;
	
	//Default Constructor
	Material() {
		setStore("Unknown");
		setLocation("Not Determined");
		setJobName("Unknown");
		setDescription("Nothing at this time.");
		setQuantity(null);
		setCost(0.00);
	}
	
	//Parameterized Constructor
	Material(String StoreName, String JobName, String MaterialDescription, Integer MaterialQuantity, double MaterialCost){
		this.StoreName = StoreName;
		this.JobName = JobName;
		this.MaterialDescription = MaterialDescription;
		this.MaterialQuantity = MaterialQuantity;
		this.MaterialCost = MaterialCost;
		StoreLocation = "N/A";
	}
	
	//Parameterized Constructor
	Material(String StoreName, String StoreLocation, String JobName, String MaterialDescription, Integer MaterialQuantity, double MaterialCost){
		this.StoreName = StoreName;
		this.StoreLocation = StoreLocation;
		this.JobName = JobName;
		this.MaterialDescription = MaterialDescription;
		this.MaterialQuantity = MaterialQuantity;
		this.MaterialCost = MaterialCost;
	}
	
	//Accessors
	public String getStore() {
		return StoreName;
	}
	public String getLocation() {
		return StoreLocation;
	}
	public String getJobName() {
		return JobName;
	}
	public String getDescription() {
		return MaterialDescription;
	}
	public Integer getQuantity() {
		return MaterialQuantity;
	}
	public double getCost() {
		return MaterialCost;
	}
	
	//Mutators
	public void setStore(String StoreName) {
		this.StoreName = StoreName;
	}
	public void setLocation(String StoreLocation) {
		this.StoreLocation = StoreLocation;
	}
	public void setJobName(String JobName) {
		this.JobName = JobName;
	}
	public void setDescription(String MaterialDescription) {
		this.MaterialDescription = MaterialDescription;
	}
	public void setQuantity(Integer MaterialQuantity) {
		this.MaterialQuantity = MaterialQuantity;
	}
	public void setCost(double MaterialCost) {
		this.MaterialCost = MaterialCost;
	}
	
	//Methods
	public double CalculateCost() {
		return getCost() * getQuantity();
	}
	
	//toString
	public String toString() {
		return "\nMaterial was purchased at: " + getStore()
		+ "\n" + getStore() + " is located: " + getLocation()
		+ "\nMaterials were purchased for: " + getJobName()
		+ "\nMaterial Description: " + getDescription()
		+ "\nMaterial Quantity: " + getQuantity()
		+ "\nMaterial Cost: $" + getCost()
		+ "\nTotal Cost: $" + String.format("%.2f", CalculateCost());
	}	
	
}