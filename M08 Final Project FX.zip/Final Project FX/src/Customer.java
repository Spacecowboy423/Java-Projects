public class Customer {
	
	//Fields
	private String First; 
	private String Last; 
	private String Address;
	private String Phone;
	private String Start_Date; 
	private String End_Date;
	private String JobStatus;
	private Integer JobID;
	private String Worker;
	
	//Default Constructor
	public Customer(){
		First = "Unknown";
		Last = "Unknown";
		Address = "Unknown";
		Phone = "Unknown";
		Start_Date = "16/16/16";
		End_Date = "16/16/16";
		JobStatus = "Not Started";
		JobID = null;
		Worker = null;
	}
	
	//Partial Parameterized Constructor
	public Customer(String First, String Last, String Address, String Phone, Integer JobID) {
		this.First = First;
		this.Last = Last;
		this.Address = Address;
		this.Phone = Phone;
		this.JobID = JobID;
		Start_Date = "Note Determined";
		End_Date = "Not Determined";
		JobStatus = "Unavailable";
		Worker = "Unassigned";
	}
	
	//Parameterized Constructor
	public Customer(String First, String Last, String Address, String Phone, String Start_Date, String End_Date, String JobStatus, Integer JobID){
		this.First = First;
		this.Last = Last;
		this.Address = Address;
		this.Phone = Phone;
		this.Start_Date = Start_Date;
		this.End_Date = End_Date;
		this.JobStatus = JobStatus;
		this.JobID = JobID;
		Worker = "Unassigned";
	}
	
	//Accessors
	public String getFirst() {
		return First;
	}
	public String getLast() {
		return Last;
	}
	public String getAddress() {
		return Address;
	}
	public String getPhone() {
		return Phone;
	}
	public String getStartDate() {
		return Start_Date;
	}
	public String getEndDate() {
		return End_Date;
	}
	public String getJobStatus() {
		return JobStatus;
	}
	public Integer getJobID() {
		return JobID;
	}
	public String getWorker() {
		return Worker;
	}
	
	//Setters
	public void setFirst(String First) {
		this.First = First;
	}
	public void setLast(String Last) {
		this.Last = Last;
	}
	public void setAddress(String Address) {
		this.Address = Address;
	}
	public void setPhone(String Phone) {
		this.Phone = Phone;
	}
	public void setStartDate(String Start_Date) {
		this.Start_Date = Start_Date;
	}
	public void setEndDate(String End_Date) {
		this.End_Date = End_Date;
	}
	public void setJobStatus(String JobStatus) {
		this.JobStatus = JobStatus;
	}
	public void setJobID(Integer JobID) {
		this.JobID = JobID;
	}
	public void setWorker(String Worker) {
		this.Worker = Worker;
	}
	
	//toString
	public String toString() {
		return "\nCustomer: " + getLast() + ", " + getFirst() 
		+ "\nAddress: " + getAddress() 
		+ "\nPhone: " + getPhone() 
		+ "\nStart Date: " + getStartDate() 
		+ "\nEnd Date: " + getEndDate() 
		+ "\nJob Status: " + getJobStatus() 
		+ "\nJob ID: " + getJobID()
		+ "\nAssigned Employee: " + getWorker();
	}
}
