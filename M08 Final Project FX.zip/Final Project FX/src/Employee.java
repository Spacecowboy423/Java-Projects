import java.util.Date;

public class Employee {
	
	//Fields
	private String First;
	private String Last;
	private String Phone;
	private Date Clock_In;
	private Date Clock_Out;
	private Integer EmpID;
	private double Wage;
	private double Rate;
	private String JobName;
	
	//Default Constructor
	Employee(){
		setFirst("Unknown");
		setLast("Unknown");
		setPhone("555-555-5555");
		setClockIn(null);
		setClockOut(null);
		setEmpID(0);
		setWage(0.00);
		setRate(0.00);
		setJobName("N/A");
	}
	
	//Parameterized Constructor
	Employee(String First, String Last, String Phone, Integer EmpID){
		this.First = First;
		this.Last = Last;
		this.Phone = Phone;
		this.EmpID = EmpID;
		JobName = "N/A";
		Clock_In = null;
		Clock_Out = null;
	}	
	
	//Parameterized Constructor
	Employee(String First, String Last, String Phone, Integer EmpID, double Rate){
		this.First = First;
		this.Last = Last;
		this.Phone = Phone;
		this.EmpID = EmpID;
		Wage = 0.00;
		this.Rate = Rate;
		JobName = "N/A";
		Clock_In = null;
		Clock_Out = null;
	}
	
	//Accessors
	public String getFirst() {
		return First;
	}
	public String getLast() {
		return Last;
	}
	public String getPhone() {
		return Phone;
	}
	public Date getClockIn() {
		return Clock_In;
	}
	public Date getClockOut() {
		return Clock_Out;
	}
	public Integer getEmpID() {
		return EmpID;
	}	
	public double getWage() {
		return Wage;
	}
	public double getRate() {
		return Rate;
	}
	public String getJobName() {
		return JobName;
	}
	
	//Mutators
	public void setFirst(String First) {
		this.First = First;
	}
	public void setLast(String Last) {
		this.Last = Last;
	}
	public void setPhone(String Phone) {
		this.Phone = Phone;
	}
	public void setClockIn(Date Clock_In) {
		this.Clock_In = Clock_In;
	}
	public void setClockOut(Date Clock_Out) {
		this.Clock_Out = Clock_Out;
	}
	public void setEmpID(Integer EmpID) {
		this.EmpID = EmpID;
	}	
	public void setRate(double Rate) {
		this.Rate = Rate;
	}
	public void setWage(double Wage) {
		this.Wage = Wage;
	}	
	public void setJobName(String JobName) {
		this.JobName = JobName;
	}
	
	//Methods
	public double CalculateWage() {
		return (((getClockOut().getTime() - getClockIn().getTime())/3.6e+6) * Rate);
	}
	
	//toString
	public String toString() {
		return "\nEmployee: " + getFirst() + " " + getLast() 
			+ "\nPhone: " + getPhone()
			+ "\nClock-In: " + getClockIn()
			+ "\nClock-Out: " + getClockOut()
			+ "\nEmployee ID: " + getEmpID()
			+ "\nRate: $" + getRate()
			+ "\nWage: $" + String.format("%.2f", getWage())
			+ "\nAssigned Job: " + getJobName(); 
	}
}
