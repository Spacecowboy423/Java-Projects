/*
Program Name: Java Construction
Author: Michael Krause
Last Updated: 12/11/21
Purpose: To simulate an application that you would use for a remodeling or construction company. 
It can clock employees in and out with the date from the system clock and report the hours for the time worked. 
Creates a searchable/changeable database for customers and inventory related to specific jobs. 
With a user friends gui interface to make everything a click away. 
*/
import java.util.HashMap;
import java.util.Map;
import java.util.Date;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {
	// Declare variables for program
	// Material variables
	String StoreName = null, StoreLocation = null, JobName = null, MaterialDescription;
	Integer MaterialQuantity = null;
	double MaterialCost;

	// Customer variables
	String First = null, Last = null, Address, Phone, StartDate, EndDate;
	Integer JobID = null;

	// Employee variables
	Integer EmpID = null;
	float Rate;

	// Initialize Text Fields Customer
	private TextField tfFirst = new TextField();
	private TextField tfLast = new TextField();
	private TextField tfPhone = new TextField();

	// Initialize Text Fields Employee
	private TextField tfEmpID = new TextField();
	private TextField tfRate = new TextField();

	// Instead of writing primaryStage, set it to window
	Stage window;

	// Main Stages
	private Scene MainStage, EmployeeStage, MaterialStage, CustomerStage;
	// Employee Stages
	private Scene AddE, DeleteE, AssignE, RemoveE, ClockInE, ClockOutE, SearchE, WageE;
	// Material Stages
	private Scene AddM, DeleteM, LocationM, RemoveM, QuantityM, PriceM, SearchM;
	// Customer Stages
	private Scene AddC, DeleteC, StartC, EndC, AssignC, RemoveC, StatusC, SearchC;

	// Buttons for Main
	private Button btMaterial = new Button("Enter Materials Database");
	private Button btCustomer = new Button("Enter Customer Database");
	private Button btEmployee = new Button("Enter Employees Database");
	private Button btQuit = new Button("Quit Program");

	// Buttons for Materials
	private Button btAddM = new Button("Assign/Change Material to Job");
	private Button btDeleteM = new Button("Delete Material from Database");
	private Button btLocationM = new Button("Add/Change Purchase Location");
	private Button btRemoveM = new Button("Remove Material from Job");
	private Button btQuantityM = new Button("Add/Change Quantity of Material");
	private Button btPriceM = new Button("Add/Change Price of Material");
	private Button btPrintM = new Button("Search Material by Job");
	private Button btExitM = new Button("Exit Database");
	private Button btSubmitM = new Button("Submit");
	private Button btGoBackM = new Button("Go Back");

	// Buttons for Customers
	private Button btAddC = new Button("Add a Customer");
	private Button btDeleteC = new Button("Delete a Customer");
	private Button btStartC = new Button("Edit Start-Date");
	private Button btEndC = new Button("Edit End-Date");
	private Button btAssignC = new Button("Assign Employee to Customer");
	private Button btRemoveC = new Button("Remove Employee from Customer");
	private Button btStatusC = new Button("Edit Job Status");
	private Button btPrintC = new Button("Search Customers");
	private Button btExitC = new Button("Exit Database");
	private Button btSubmitC = new Button("Submit");
	private Button btGoBackC = new Button("Go Back");

	// Buttons for Employees
	private Button btAddE = new Button("Add An Employee");
	private Button btDeleteE = new Button("Delete An Employee");
	private Button btAssignE = new Button("Assign Employee To Job");
	private Button btRemoveE = new Button("Remove Employee From Job");
	private Button btClockInE = new Button("Clock-In");
	private Button btClockOutE = new Button("Clock-Out");
	private Button btPrintE = new Button("Search Employee");
	private Button btWageE = new Button("Get Wage From Time Clock");
	private Button btExitE = new Button("Exit Database");
	private Button btSubmitE = new Button("Submit");
	private Button btGoBackE = new Button("Go Back");

	//
	//
	//
	@Override
	public void start(Stage primaryStage) throws Exception {
		//
		window = primaryStage;

		// Map for materials with elements chosen by developer
		Map<String, Material> material = new HashMap<String, Material>();
		material.put("Smith", new Material("Lowes", "Smith", "Lumber 2x4x8", 20, 9.80));
		material.put("Craig", new Material("D&D Molding", "Craig", "Base Molding 4x3/4x16", 12, 12.85));
		material.put("Johnson", new Material("Louisville Tile", "Johnson", "Marble Tile 3x4", 100, 22.50));
		material.put("Reynolds", new Material("Pro Flooring", "Reynolds", "Vinyl Plank Flooring", 400, 10.20));

		// Map for customers with elements chosen by developer
		Map<Integer, Customer> customer = new HashMap<Integer, Customer>();
		customer.put(1, new Customer("Terry", "Smith", "11136 Sweet Dreams Lane", "317-555-8293", 1));
		customer.put(2, new Customer("Daniel", "Craig", "007 Skyfall Drive", "266-305-2637", 2));
		customer.put(3, new Customer("Dwayne", "Johnson", "1234 Rockfall Court", "123-555-8465", 3));
		customer.put(4, new Customer("Ryan", "Reynolds", "111 Hollywood Boulevard", "213-555-0245", 4));

		// Map for employees with elements chosen by developer
		Map<Integer, Employee> employee = new HashMap<Integer, Employee>();
		employee.put(1, new Employee("Spike", "Spiegel", "102-419-9801", 1, 50.00));
		employee.put(2, new Employee("Jet", "Black", "102-419-9802", 2, 50.00));
		employee.put(3, new Employee("Faye", "Valentine", "102-719-9803", 3, 50.00));
		employee.put(4, new Employee("Edward", "Tomato", "112-219-9804", 4, 75.00));
		employee.put(5, new Employee("Ein", "Datadog", "110-619-9803", 5, 80.00));

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// Create Event Driven Buttons for MainStage
		Label MainLabel = new Label("How can I help you today?");
		btMaterial.setOnAction(e -> {
			window.setScene(MaterialStage);
			window.setTitle("Materials Database");
		});
		btCustomer.setOnAction(e -> {
			window.setScene(CustomerStage);
			window.setTitle("Customer Database");
		});
		btEmployee.setOnAction(e -> {
			window.setScene(EmployeeStage);
			window.setTitle("Employee Database");
		});
		btQuit.setOnAction(e -> {
			window.close();
		});
		// Create Layout for Mainstage Scene
		VBox Mainlayout = new VBox(20);
		Mainlayout.getChildren().addAll(MainLabel, btMaterial, btCustomer, btEmployee, btQuit);
		MainStage = new Scene(Mainlayout, 300, 250);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// Create Event Driven Buttons for MaterialStage
		Label MaterialLabel = new Label("Materials are heavy, lets help lighten the load.");
		btAddM.setOnAction(e -> {
			window.setScene(AddM);
			window.setTitle("Add Material");
		});
		btDeleteM.setOnAction(e -> {
			window.setScene(DeleteM);
			window.setTitle("Delete Material");
		});
		btLocationM.setOnAction(e -> {
			window.setScene(LocationM);
			window.setTitle("Where'd You Buy It?");
		});
		btRemoveM.setOnAction(e -> {
			window.setScene(RemoveM);
			window.setTitle("Remove Material From Job");
		});
		btQuantityM.setOnAction(e -> {
			window.setScene(QuantityM);
			window.setTitle("Quantity Of Material");
		});
		btPriceM.setOnAction(e -> {
			window.setScene(PriceM);
			window.setTitle("Cost Of Material");
		});
		btPrintM.setOnAction(e -> {
			window.setScene(SearchM);
			window.setTitle("Search Database For Material Attached To Job");
		});
		btExitM.setOnAction(e -> {
			window.setScene(MainStage);
			window.setTitle("Main Menu");
		});
		// Create Layout for MaterialStage Scene
		VBox Materiallayout = new VBox(20);
		Materiallayout.getChildren().addAll(MaterialLabel, btAddM, btDeleteM, btLocationM, btRemoveM, btQuantityM,
				btPriceM, btPrintM, btExitM);
		MaterialStage = new Scene(Materiallayout, 400, 450);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// Create Event Driven Buttons for CustomerStage
		Label CustomerLabel = new Label("Let us get these customer straightened out.");
		btAddC.setOnAction(e -> {
			window.setScene(AddC);
			window.setTitle("Add Customer");
		});
		btDeleteC.setOnAction(e -> {
			window.setScene(DeleteC);
			window.setTitle("Delete Customer");
		});
		btStartC.setOnAction(e -> {
			window.setScene(StartC);
			window.setTitle("Start Date Of Job");
		});
		btEndC.setOnAction(e -> {
			window.setScene(EndC);
			window.setTitle("End Date Of Job");
		});
		btAssignC.setOnAction(e -> {
			window.setScene(AssignC);
			window.setTitle("Assign Employee To Customer");
		});
		btRemoveC.setOnAction(e -> {
			window.setScene(RemoveC);
			window.setTitle("Remove Employee From Customer");
		});
		btStatusC.setOnAction(e -> {
			window.setScene(StatusC);
			window.setTitle("Status Of Job");
		});
		btPrintC.setOnAction(e -> {
			window.setScene(SearchC);
			window.setTitle("Find Customer Info");
		});
		btExitC.setOnAction(e -> {
			window.setScene(MainStage);
			window.setTitle("Main Menu");
		});
		// Create Layout for CustomerStage Scene
		VBox Customerlayout = new VBox(20);
		Customerlayout.getChildren().addAll(CustomerLabel, btAddC, btDeleteC, btStartC, btEndC, btAssignC, btRemoveC,
				btStatusC, btPrintC, btExitC);
		CustomerStage = new Scene(Customerlayout, 400, 500);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// Create Event Driven Buttons for EmployeeStage
		Label EmployeeLabel = new Label("Let's help get you started.");
		btAddE.setOnAction(e -> {
			window.setScene(AddE);
			window.setTitle("More The Merrier");
		});
		btDeleteE.setOnAction(e -> {
			window.setScene(DeleteE);
			window.setTitle("Gone For Good");
		});
		btAssignE.setOnAction(e -> {
			window.setScene(AssignE);
			window.setTitle("We Like This One");
		});
		btRemoveE.setOnAction(e -> {
			window.setScene(RemoveE);
			window.setTitle("Get'em Outta Here");
		});
		btClockInE.setOnAction(e -> {
			window.setScene(ClockInE);
			window.setTitle("Make That Money");
		});
		btClockOutE.setOnAction(e -> {
			window.setScene(ClockOutE);
			window.setTitle("Rest Them Bones");
		});
		btPrintE.setOnAction(e -> {
			window.setScene(SearchE);
			window.setTitle("Gotta Find'em All");
		});
		btWageE.setOnAction(e -> {
			window.setScene(WageE);
			window.setTitle("Let's Get Those Wages!");
		});
		btExitE.setOnAction(e -> {
			window.setScene(MainStage);
			window.setTitle("Main Menu");
		});
		// Create Layout for EmployeeStage Scene
		VBox Employeelayout = new VBox(20);
		Employeelayout.getChildren().addAll(EmployeeLabel, btAddE, btDeleteE, btAssignE, btRemoveE, btClockInE,
				btClockOutE, btPrintE, btWageE, btExitE);
		EmployeeStage = new Scene(Employeelayout, 400, 500);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// Material SubStages
		// AddM Labels
		Label StoreNameM = new Label("Store Name:");
		Label StoreLocationM = new Label("Store Location:");
		Label JobNameM = new Label("Job Name:");
		Label MaterialDescriptionM = new Label("Material Description:");
		Label MaterialQuantityM = new Label("Quantity Of Material:");
		Label MaterialCostM = new Label("Cost Per Item");
		// Initialize Text Fields Customer
		TextField tfStoreNameM = new TextField();
		TextField tfStoreLocationM = new TextField();
		TextField tfJobNameM = new TextField();
		TextField tfMaterialDescriptionM = new TextField();
		TextField tfMaterialQuantityM = new TextField();
		TextField tfMaterialCostM = new TextField();

		btSubmitM.setOnAction(e -> {
			// Create new employee from user input
			StoreName = tfStoreNameM.getText();
			StoreLocation = tfStoreLocationM.getText();
			JobName = tfJobNameM.getText();
			MaterialDescription = tfMaterialDescriptionM.getText();
			MaterialQuantity = Integer.parseInt(tfMaterialQuantityM.getText());
			MaterialCost = Double.parseDouble(tfMaterialCostM.getText());
			if (material.containsKey(JobName) != true) {
				// Create new employee from user input
				material.put(JobName, new Material(StoreName, StoreLocation, JobName, MaterialDescription,
						MaterialQuantity, MaterialCost));
				System.out.println("New Material has been added to job: " + material.get(JobName).getJobName());
			} else if (material.containsKey(JobName)) {
				material.get(JobName).setStore(StoreName);
				material.get(JobName).setLocation(StoreLocation);
				material.get(JobName).setDescription(MaterialDescription);
				material.get(JobName).setQuantity(MaterialQuantity);
				material.get(JobName).setCost(MaterialCost);
				System.out.println("Material has been updated for job: " + material.get(JobName).getJobName());
			}
			// Clear the textfields before calling the previous scene
			tfStoreNameM.clear();
			tfStoreLocationM.clear();
			tfJobNameM.clear();
			tfMaterialDescriptionM.clear();
			tfMaterialQuantityM.clear();
			tfMaterialCostM.clear();
		});

		btGoBackM.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfStoreNameM.clear();
			tfStoreLocationM.clear();
			tfJobNameM.clear();
			tfMaterialDescriptionM.clear();
			tfMaterialQuantityM.clear();
			tfMaterialCostM.clear();
			window.setScene(MaterialStage);
			window.setTitle("Customer Materials Database");
		});

		VBox AddMlayout = new VBox(10);
		AddMlayout.getChildren().addAll(StoreNameM, tfStoreNameM, StoreLocationM, tfStoreLocationM, JobNameM,
				tfJobNameM, MaterialDescriptionM, tfMaterialDescriptionM, MaterialQuantityM, tfMaterialQuantityM,
				MaterialCostM, tfMaterialCostM, btSubmitM, btGoBackM);
		AddM = new Scene(AddMlayout, 400, 550);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// DeleteM
		Label JobNameM1 = new Label("Job Name:");
		// Initialize Text Fields Customer
		TextField tfJobNameM1 = new TextField();

		Button btSubmitM1 = new Button("Remove Material From Job");
		btSubmitM1.setOnAction(e -> {
			// Create new employee from user input
			JobName = tfJobNameM1.getText();
			if (material.containsKey(JobName)) {
				material.remove(JobName, material);
				material.remove(JobName);
				System.out.println("Material associated to job (" + JobName + ") has been deleted from database.");
			} else {
				System.out.println("Specified material does not exist within database.");
			}
			// Clear the textfields before calling the previous scene
			tfJobNameM1.clear();
		});

		Button btGoBackM1 = new Button("Go Back");
		btGoBackM1.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfJobNameM1.clear();
			window.setScene(MaterialStage);
			window.setTitle("Customer Materials Database");
		});

		VBox DeleteMlayout = new VBox(10);
		DeleteMlayout.getChildren().addAll(JobNameM1, tfJobNameM1, btSubmitM1, btGoBackM1);
		DeleteM = new Scene(DeleteMlayout, 400, 200);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// LocationM
		Label StoreLocationM2 = new Label("Store Location:");
		Label JobNameM2 = new Label("Job Name:");
		// Initialize Text Fields Customer
		TextField tfStoreLocationM2 = new TextField();
		TextField tfJobNameM2 = new TextField();

		Button btSubmitM2 = new Button("Confirm Purchase Location");
		btSubmitM2.setOnAction(e -> {
			// Create new employee from user input
			JobName = tfJobNameM2.getText();
			// Check Object exists before assigning a Location
			if (material.containsKey(JobName)) {
				material.get(JobName).setLocation(tfStoreLocationM2.getText());
				System.out.println("The Store Location has been changed to " + material.get(JobName).getLocation());
			} else {
				System.out.println(
						"Material object does not exist in database. Check JobName attached to material and try again.");
			}
			// Clear the textfields before calling the previous scene
			tfStoreLocationM2.clear();
			tfJobNameM2.clear();
		});

		Button btGoBackM2 = new Button("Go Back");
		btGoBackM2.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfStoreLocationM2.clear();
			tfJobNameM2.clear();
			window.setScene(MaterialStage);
			window.setTitle("Customer Materials Database");
		});

		VBox LocationMlayout = new VBox(10);
		LocationMlayout.getChildren().addAll(StoreLocationM2, tfStoreLocationM2, JobNameM2, tfJobNameM2, btSubmitM2,
				btGoBackM2);
		LocationM = new Scene(LocationMlayout, 400, 250);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// RemoveM
		Label JobNameM3 = new Label("Job Name:");
		// Initialize Text Fields Customer
		TextField tfJobNameM3 = new TextField();

		Button btSubmitM3 = new Button("Remove Material");
		btSubmitM3.setOnAction(e -> {
			// Create new employee from user input
			JobName = tfJobNameM3.getText();
			// Check Object exists before removing contents of the Material
			if (material.containsKey(JobName) && material.get(JobName).getDescription() != null
					&& material.get(JobName).getQuantity() != null) {
				// material.get(JobName).setJobName(null);
				material.get(JobName).setDescription(null);
				material.get(JobName).setQuantity(null);
				material.get(JobName).setCost(0);
				System.out.println(
						"Material has been removed from the, " + material.get(JobName).getJobName() + ", job.");
			} else if (material.containsKey(JobName) && material.get(JobName).getDescription() == null) {
				System.out.println(
						"There is no material associated to the, " + material.get(JobName).getJobName() + " job.");
			} else {
				System.out.println("Specified job does not exist within the database.");
			}
			// Clear the textfields before calling the previous scene
			tfJobNameM3.clear();
		});

		Button btGoBackM3 = new Button("Go Back");
		btGoBackM3.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfJobNameM2.clear();
			window.setScene(MaterialStage);
			window.setTitle("Customer Materials Database");
		});

		VBox RemoveMlayout = new VBox(20);
		RemoveMlayout.getChildren().addAll(JobNameM3, tfJobNameM3, btSubmitM3, btGoBackM3);
		RemoveM = new Scene(RemoveMlayout, 400, 250);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// QuantityM
		Label JobNameM4 = new Label("Job Name:");
		Label MaterialQuantityM4 = new Label("Quantity Of Material:");
		// Initialize Text Fields Customer
		TextField tfJobNameM4 = new TextField();
		TextField tfMaterialQuantityM4 = new TextField();

		Button btSubmitM4 = new Button("Submit Quantity");
		btSubmitM4.setOnAction(e -> {
			// Create new employee from user input
			JobName = tfJobNameM4.getText();
			MaterialQuantity = Integer.parseInt(tfMaterialQuantityM4.getText());
			// Check material object exists before changing the Quantity
			if (material.containsKey(JobName)) {
				System.out.println("The current quantity of " + material.get(JobName).getDescription() + ", is "
						+ material.get(JobName).getQuantity());
				System.out.println("Material quantity for, " + material.get(JobName).getJobName()
						+ ", has been changed to " + material.get(JobName).getQuantity());
			} else {
				System.out
						.println("Job does not exist in database. Check Job Name attached to material and try again.");
			}
			// Clear the textfields before calling the previous scene
			tfJobNameM4.clear();
			tfMaterialQuantityM4.clear();
		});

		Button btGoBackM4 = new Button("Go Back");
		btGoBackM4.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfJobNameM4.clear();
			tfMaterialQuantityM4.clear();
			window.setScene(MaterialStage);
			window.setTitle("Materials Database");
		});

		VBox QuantityMlayout = new VBox(10);
		QuantityMlayout.getChildren().addAll(JobNameM4, tfJobNameM4, MaterialQuantityM4, tfMaterialQuantityM4,
				btSubmitM4, btGoBackM4);
		QuantityM = new Scene(QuantityMlayout, 400, 250);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// PriceM
		Label JobNameM5 = new Label("Job Name:");
		Label MaterialCostM5 = new Label("Cost Per Item");
		// Initialize Text Fields Customer
		TextField tfJobNameM5 = new TextField();
		TextField tfMaterialCostM5 = new TextField();

		Button btSubmitM5 = new Button("Submit Cost Per Item");
		btSubmitM5.setOnAction(e -> {
			// Create new employee from user input
			JobName = tfJobNameM5.getText();
			MaterialCost = Double.parseDouble(tfMaterialCostM5.getText());
			// Check material object exists before changing the price
			if (material.containsKey(JobName)) {
				System.out.println("The current price of " + material.get(JobName).getDescription() + ", is $"
						+ material.get(JobName).getCost());
				System.out.println("Price has been changed to " + material.get(JobName).getCost());
			} else {
				System.out
						.println("Job does not exist in database. Check Job Name attached to material and try again.");
			}
			// Clear the textfields before calling the previous scene
			tfJobNameM5.clear();
			tfMaterialCostM5.clear();
		});

		Button btGoBackM5 = new Button("Go Back");
		btGoBackM5.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfJobNameM5.clear();
			tfMaterialCostM5.clear();
			window.setScene(MaterialStage);
			window.setTitle("Customer Materials Database");
		});

		VBox PriceMlayout = new VBox(10);
		PriceMlayout.getChildren().addAll(JobNameM5, tfJobNameM5, MaterialCostM5, tfMaterialCostM5, btSubmitM5,
				btGoBackM5);
		PriceM = new Scene(PriceMlayout, 400, 250);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// SearchM
		Label JobNameM6 = new Label("Job Name:");
		// Initialize Text Fields Customer
		TextField tfJobNameM6 = new TextField();

		Button btSubmitM6 = new Button("Search");
		btSubmitM6.setOnAction(e -> {
			// Create new employee from user input
			JobName = tfJobNameM6.getText();
			// Check job exists before printing results
			if (material.containsKey(JobName)) {
				System.out.println(material.get(JobName).toString());
			} else {
				System.out.println("Specified job does not exist within database.");
			}
			// Clear the textfields before calling the previous scene
			tfJobNameM6.clear();
		});

		Button btGoBackM6 = new Button("Go Back");
		btGoBackM6.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfJobNameM6.clear();
			window.setScene(MaterialStage);
			window.setTitle("Customer Materials Database");
		});

		VBox SearchMlayout = new VBox(10);
		SearchMlayout.getChildren().addAll(JobNameM6, tfJobNameM6, btSubmitM6, btGoBackM6);
		SearchM = new Scene(SearchMlayout, 400, 200);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// Customer SubStages
		// AddC Labels
		Label FirstC = new Label("First Name:");
		Label LastC = new Label("Last Name:");
		Label PhoneC = new Label("Phone Number:");
		Label AddressC = new Label("Address:");
		Label JobIDC = new Label("ID Number:");
		// Initialize Text Fields Customer
		TextField tfFirstC = new TextField();
		TextField tfLastC = new TextField();
		TextField tfAddressC = new TextField();
		TextField tfPhoneC = new TextField();
		TextField tfJobIDC = new TextField();

		btSubmitC.setOnAction(e -> {
			// Create new employee from user input
			First = tfFirstC.getText();
			Last = tfLastC.getText();
			Address = tfAddressC.getText();
			Phone = tfPhoneC.getText();
			String ID = tfJobIDC.getText();
			JobID = Integer.parseInt(ID);
			if (customer.containsKey(JobID) != true) {
				// Create new employee from user input
				customer.put(JobID, new Customer(First, Last, Address, Phone, JobID));
				System.out.println("New customer " + customer.get(JobID).getFirst() + " "
						+ customer.get(JobID).getLast() + " has been added successfully.");
			} else if (customer.containsKey(JobID)) {
				customer.get(JobID).setFirst(First);
				customer.get(JobID).setLast(Last);
				customer.get(JobID).setAddress(Address);
				customer.get(JobID).setPhone(Phone);
				System.out.println("Customer has been updated to " + customer.get(JobID).getFirst() + " "
						+ customer.get(JobID).getLast());
			}
			// Clear the textfields before calling the previous scene
			tfFirstC.clear();
			tfLastC.clear();
			tfAddressC.clear();
			tfPhoneC.clear();
			tfJobIDC.clear();
		});

		btGoBackC.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfFirstC.clear();
			tfLastC.clear();
			tfAddressC.clear();
			tfPhoneC.clear();
			tfJobIDC.clear();
			window.setScene(CustomerStage);
			window.setTitle("Customer Database");
		});

		VBox AddClayout = new VBox(10);
		AddClayout.getChildren().addAll(FirstC, tfFirstC, LastC, tfLastC, AddressC, tfAddressC, PhoneC, tfPhoneC,
				JobIDC, tfJobIDC, btSubmitC, btGoBackC);
		AddC = new Scene(AddClayout, 400, 500);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// DeleteC
		Label JobIDC1 = new Label("ID Number:");
		// Initialize Text Fields Customer
		TextField tfJobIDC1 = new TextField();

		Button btSubmitC1 = new Button("Delete Customer");
		btSubmitC1.setOnAction(e -> {
			// Create new employee from user input
			String ID = tfJobIDC1.getText();
			JobID = Integer.parseInt(ID);
			if (customer.containsKey(JobID)) {
				customer.remove(JobID, customer);
				customer.remove(JobID);
				System.out.println("Specified customer has been removed from the database.");
			} else {
				System.out.println("Specified customer does not exist within database.");
			}
			// Clear the textfields before calling the previous scene
			tfJobIDC1.clear();
		});

		Button btGoBackC1 = new Button("Go Back");
		btGoBackC1.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfJobIDC1.clear();
			window.setScene(CustomerStage);
			window.setTitle("Customer Database");
		});

		VBox DeleteClayout = new VBox(10);
		DeleteClayout.getChildren().addAll(JobIDC1, tfJobIDC1, btSubmitC1, btGoBackC1);
		DeleteC = new Scene(DeleteClayout, 400, 500);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// StartC
		Label StartC2 = new Label("Start Date:");
		Label JobIDC2 = new Label("ID Number:");
		// Initialize Text Fields Customer
		TextField tfStartC2 = new TextField();
		TextField tfJobIDC2 = new TextField();

		Button btSubmitC2 = new Button("Submit Date");
		btSubmitC2.setOnAction(e -> {
			// Create new employee from user input
			StartDate = tfStartC2.getText();
			String ID = tfJobIDC2.getText();
			JobID = Integer.parseInt(ID);
			// Check employee exists before assigning a job
			if (customer.containsKey(JobID)) {
				customer.get(JobID).setStartDate(StartDate);
				System.out.println("Customer " + customer.get(JobID).getLast() + " has had their Start Date Updated.");
			} else {
				System.out.println("Customer does not exist in database. Check customer ID and try again.");
			}
			// Clear the textfields before calling the previous scene
			tfStartC2.clear();
			tfJobIDC2.clear();
		});

		Button btGoBackC2 = new Button("Go Back");
		btGoBackC2.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfStartC2.clear();
			tfJobIDC2.clear();
			window.setScene(CustomerStage);
			window.setTitle("Customer Database");
		});

		VBox StartClayout = new VBox(10);
		StartClayout.getChildren().addAll(StartC2, tfStartC2, JobIDC2, tfJobIDC2, btSubmitC2, btGoBackC2);
		StartC = new Scene(StartClayout, 400, 500);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// EndC
		Label EndC3 = new Label("End Date:");
		Label JobIDC3 = new Label("ID Number:");
		// Initialize Text Fields Customer
		TextField tfEndC3 = new TextField();
		TextField tfJobIDC3 = new TextField();

		Button btSubmitC3 = new Button("Submit Date");
		btSubmitC3.setOnAction(e -> {
			// Create new employee from user input
			EndDate = tfEndC3.getText();
			String ID = tfJobIDC3.getText();
			JobID = Integer.parseInt(ID);
			// Check employee exists before assigning a job
			if (customer.containsKey(JobID)) {
				customer.get(JobID).setEndDate(EndDate);
				System.out.println("Customer " + customer.get(JobID).getLast() + " has had their End Date Updated.");
			} else {
				System.out.println("Customer does not exist in database. Check customer ID and try again.");
			}
			// Clear the textfields before calling the previous scene
			tfEndC3.clear();
			tfJobIDC3.clear();
		});

		Button btGoBackC3 = new Button("Go Back");
		btGoBackC3.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfEndC3.clear();
			tfJobIDC3.clear();
			window.setScene(CustomerStage);
			window.setTitle("Customer Database");
		});

		VBox EndClayout = new VBox(10);
		EndClayout.getChildren().addAll(EndC3, tfEndC3, JobIDC3, tfJobIDC3, btSubmitC3, btGoBackC3);
		EndC = new Scene(EndClayout, 400, 500);

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// AssignC
		Label WorkerC4 = new Label("Employees Name:");
		Label JobIDC4 = new Label("ID Number:");
		// Initialize Text Fields Customer
		TextField tfWorkerC4 = new TextField();
		TextField tfJobIDC4 = new TextField();

		Button btSubmitC4 = new Button("Assign Employee");
		btSubmitC4.setOnAction(e -> {
			// Create new employee from user input
			String Worker = tfWorkerC4.getText();
			String ID = tfJobIDC4.getText();
			JobID = Integer.parseInt(ID);
			// Check customer exists before assigning an employee
			if (customer.containsKey(JobID)) {
				System.out.println(customer.get(JobID).getFirst() + " " + customer.get(JobID).getLast()
						+ ", will have an employee assigned.");
				customer.get(JobID).setWorker(Worker);
				System.out.println(customer.get(JobID).getWorker() + " has been assigned to the "
						+ customer.get(JobID).getLast() + " job.");
			} else {
				System.out.println("Customer does not exist in database. Check customer ID and try again.");
			}
			// Clear the textfields before calling the previous scene
			tfWorkerC4.clear();
			tfJobIDC4.clear();
		});

		Button btGoBackC4 = new Button("Go Back");
		btGoBackC4.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfWorkerC4.clear();
			tfJobIDC4.clear();
			window.setScene(CustomerStage);
			window.setTitle("Customer Database");
		});

		VBox AssignClayout = new VBox(10);
		AssignClayout.getChildren().addAll(WorkerC4, tfWorkerC4, JobIDC4, tfJobIDC4, btSubmitC4, btGoBackC4);
		AssignC = new Scene(AssignClayout, 400, 500);

		///////////////////////////////////////////////////////////////////////////////////////////////////////////
		// RemoveC
		Label WorkerC5 = new Label("Employees Name:");
		Label JobIDC5 = new Label("ID Number:");
		// Initialize Text Fields Customer
		TextField tfWorkerC5 = new TextField();
		TextField tfJobIDC5 = new TextField();

		Button btSubmitC5 = new Button("Remove Employee");
		btSubmitC5.setOnAction(e -> {
			// Create new employee from user input
			String Worker = tfWorkerC5.getText();
			String ID = tfJobIDC5.getText();
			JobID = Integer.parseInt(ID);
			// Check customer exists before assigning an employee
			if (customer.containsKey(JobID)) {
				System.out.println(customer.get(JobID).getFirst() + " " + customer.get(JobID).getLast()
						+ ", will have an employee removed.");
				customer.get(JobID).setWorker(null);
				System.out.println(Worker + " is no longer assigned. " + customer.get(JobID).getWorker()
						+ " is now assigned to the " + customer.get(JobID).getLast() + " job.");
			} else {
				System.out.println("Customer does not exist in database. Check customer ID and try again.");
			}
			// Clear the textfields before calling the previous scene
			tfWorkerC5.clear();
			tfJobIDC5.clear();
		});

		Button btGoBackC5 = new Button("Go Back");
		btGoBackC5.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfWorkerC5.clear();
			tfJobIDC5.clear();
			window.setScene(CustomerStage);
			window.setTitle("Customer Database");
		});

		VBox RemoveClayout = new VBox(10);
		RemoveClayout.getChildren().addAll(WorkerC5, tfWorkerC5, JobIDC5, tfJobIDC5, btSubmitC5, btGoBackC5);
		RemoveC = new Scene(RemoveClayout, 400, 500);

		///////////////////////////////////////////////////////////////////////////////////////////////////////////
		// StatusC
		Label JobIDC6 = new Label("ID Number:");
		Label StatusC6 = new Label("Activity On Job:");
		// Initialize Text Fields Customer
		TextField tfJobIDC6 = new TextField();
		TextField tfStatusC6 = new TextField();

		Button btSubmitC6 = new Button("Update Job Status");
		btSubmitC6.setOnAction(e -> {
			// Create new employee from user input
			String Status = tfStatusC6.getText();
			String ID = tfJobIDC6.getText();
			JobID = Integer.parseInt(ID);
			if (customer.containsKey(JobID)) {
				customer.get(JobID).setJobStatus(Status);
				System.out.println("Customer, " + customer.get(JobID).getLast()
						+ ", job status has been successfully updated to " + customer.get(JobID).getJobStatus() + ".");
			} else {
				System.out.println("Specified Job ID does not exist within database.");
			}
			// Clear the textfields before calling the previous scene
			tfStatusC6.clear();
			tfJobIDC6.clear();
		});

		Button btGoBackC6 = new Button("Go Back");
		btGoBackC6.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfStatusC6.clear();
			tfJobIDC6.clear();
			window.setScene(CustomerStage);
			window.setTitle("Customer Database");
		});

		VBox StatusClayout = new VBox(10);
		StatusClayout.getChildren().addAll(StatusC6, tfStatusC6, JobIDC6, tfJobIDC6, btSubmitC6, btGoBackC6);
		StatusC = new Scene(StatusClayout, 400, 500);

		///////////////////////////////////////////////////////////////////////////////////////////////////////////
		// SearchM
		Label JobIDC7 = new Label("ID Number:");
		// Initialize Text Fields Customer
		TextField tfJobIDC7 = new TextField();

		Button btSubmitC7 = new Button("Search Customer DataBase");
		btSubmitC7.setOnAction(e -> {
			// Create new employee from user input
			String ID = tfJobIDC7.getText();
			JobID = Integer.parseInt(ID);
			if (customer.containsKey(JobID)) {
				System.out.println(customer.get(JobID).toString());
			} else {
				System.out.println("Specified Job ID does not exist within database.");
			}
			// Clear the textfields before calling the previous scene
			tfJobIDC7.clear();
		});

		Button btGoBackC7 = new Button("Go Back");
		btGoBackC7.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfJobIDC7.clear();
			window.setScene(CustomerStage);
			window.setTitle("Customer Database");
		});

		VBox SearchClayout = new VBox(10);
		SearchClayout.getChildren().addAll(JobIDC7, tfJobIDC7, btSubmitC7, btGoBackC7);
		SearchC = new Scene(SearchClayout, 400, 500);

		////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		// Employee SubStages
		// AddE Scene
		Label FirstE = new Label("First Name:");
		Label LastE = new Label("Last Name:");
		Label PhoneE = new Label("Phone Number:");
		Label EmpIDE = new Label("ID Number:");
		Label RateE = new Label("Pay Rate:");

		btSubmitE.setOnAction(e -> {
			// Create new employee from user input
			String ID = tfEmpID.getText();
			EmpID = Integer.parseInt(ID);
			if (employee.containsKey(EmpID) != true) {
				First = tfFirst.getText();
				Last = tfLast.getText();
				Phone = tfPhone.getText();
				String Money = tfRate.getText();
				Rate = Float.parseFloat(Money);
				employee.put(EmpID, new Employee(First, Last, Phone, EmpID, Rate));
				System.out.println("Employee has been added to the database.");

			}
			if (employee.containsKey(EmpID)) {
				employee.get(EmpID).setFirst(First);
				employee.get(EmpID).setLast(Last);
				employee.get(EmpID).setPhone(Phone);
				employee.get(EmpID).setEmpID(EmpID);
				employee.get(EmpID).setRate(Rate);
				System.out.println("Updated employee " + employee.get(EmpID).getFirst() + " "
						+ employee.get(EmpID).getLast() + " successfully.");

			}
			// Clear the textfields after submission whether right or wrong
			tfFirst.clear();
			tfLast.clear();
			tfPhone.clear();
			tfEmpID.clear();
			tfRate.clear();
		});

		btGoBackE.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfFirst.clear();
			tfLast.clear();
			tfPhone.clear();
			tfEmpID.clear();
			tfRate.clear();
			window.setScene(EmployeeStage);
			window.setTitle("Employee Database");
		});

		VBox AddElayout = new VBox(10);
		AddElayout.getChildren().addAll(FirstE, tfFirst, LastE, tfLast, PhoneE, tfPhone, EmpIDE, tfEmpID, RateE, tfRate,
				btSubmitE, btGoBackE);
		AddE = new Scene(AddElayout, 400, 500);

		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		// DeleteE Scene
		Label EmpIDE1 = new Label("ID Number:");
		// Initialize Text Fields Employee
		TextField tfEmpID1 = new TextField();
		Button btDeleteEmployee = new Button("Delete Employee");

		btDeleteEmployee.setOnAction(e -> {
			// Create new employee from user input
			String ID = tfEmpID1.getText();
			EmpID = Integer.parseInt(ID);
			if (employee.containsKey(EmpID)) {
				employee.remove(EmpID, employee);
				employee.remove(EmpID);
				System.out.println("Employee has been successfully removed from the database.");
				window.setScene(EmployeeStage);
				window.setTitle("Employee Database");
			} else {
				System.out.println("Employee with specified ID does not exist within database.");
			}
			// Clear the textfields after submission whether right or wrong
			tfEmpID1.clear();
		});

		Button btDontDeleteEmployee = new Button("Go Back");
		btDontDeleteEmployee.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfEmpID1.clear();
			window.setScene(EmployeeStage);
			window.setTitle("Employee Database");
		});

		VBox DeleteElayout = new VBox(20);
		DeleteElayout.getChildren().addAll(EmpIDE1, tfEmpID1, btDeleteEmployee, btDontDeleteEmployee);
		DeleteE = new Scene(DeleteElayout, 300, 200);

		///////////////////////////////////////////////////////////////////////////////////////////////////////
		// AssignE
		Label EmpIDE2 = new Label("ID Number:");
		Label JobNameE2 = new Label("Customers Last Name:");
		// Initialize Text Fields Employee
		TextField tfEmpID2 = new TextField();
		TextField tfJobName2 = new TextField();

		Button btAssignEmployee = new Button("Assign Employee");
		btAssignEmployee.setOnAction(e -> {
			// Create new employee from user input
			String ID = tfEmpID2.getText();
			EmpID = Integer.parseInt(ID);
			if (employee.containsKey(EmpID)) {
				employee.get(EmpID).setJobName(tfJobName2.getText());
				System.out.println("Employee " + employee.get(EmpID).getFirst() + " " + employee.get(EmpID).getLast()
						+ " has been successfully assigned to the " + employee.get(EmpID).getJobName() + " job.");
				window.setScene(EmployeeStage);
				window.setTitle("Employee Database");
			} else {
				System.out.println("Employee does not exist in database. Check employee ID and try again.");
			}
			// Clear the textfields after submission whether right or wrong
			tfEmpID2.clear();
			tfJobName2.clear();
		});

		Button btDontAssignEmployee = new Button("Go Back");
		btDontAssignEmployee.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfEmpID2.clear();
			tfJobName2.clear();
			window.setScene(EmployeeStage);
			window.setTitle("Employee Database");
		});

		VBox AssignElayout = new VBox(20);
		AssignElayout.getChildren().addAll(EmpIDE2, tfEmpID2, JobNameE2, tfJobName2, btAssignEmployee,
				btDontAssignEmployee);
		AssignE = new Scene(AssignElayout, 300, 300);

		///////////////////////////////////////////////////////////////////////////////////////////////////////////
		// RemoveE
		Label EmpIDE3 = new Label("ID Number:");
		Label JobNameE3 = new Label("Customers Last Name:");
		// Initialize Text Fields Employee
		TextField tfEmpID3 = new TextField();
		TextField tfJobName3 = new TextField();
		Button btRemoveEmployee = new Button("Remove Employee From Job");

		btRemoveEmployee.setOnAction(e -> {
			// Check employee exists before assigning a job
			String ID = tfEmpID3.getText();
			EmpID = Integer.parseInt(ID);
			if (employee.containsKey(EmpID)) {
				System.out.println("Employee " + employee.get(EmpID).getFirst() + " " + employee.get(EmpID).getLast()
						+ ", is longer assigned to a job.");
				employee.get(EmpID).setJobName(null);
			} else {
				System.out.println("Employee does not exist in database. Check employee ID and try again.");
			}
			// Clear after each click
			tfEmpID3.clear();
			tfJobName3.clear();
		});

		Button btDontRemoveEmployee = new Button("Go Back");
		btDontRemoveEmployee.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfEmpID3.clear();
			tfJobName3.clear();
			window.setScene(EmployeeStage);
			window.setTitle("Employee Database");
		});

		VBox RemoveElayout = new VBox(20);
		RemoveElayout.getChildren().addAll(EmpIDE3, tfEmpID3, JobNameE3, tfJobName3, btRemoveEmployee,
				btDontRemoveEmployee);
		RemoveE = new Scene(RemoveElayout, 300, 300);

		///////////////////////////////////////////////////////////////////////////////////////////////
		// ClockInE
		Label EmpIDE4 = new Label("ID Number:");
		// Initialize Text Fields Employee
		TextField tfEmpID4 = new TextField();

		Button btClockIn = new Button("Clock In");
		btClockIn.setOnAction(e -> {
			// Create new employee from user input
			String ID = tfEmpID4.getText();
			EmpID = Integer.parseInt(ID);
			if (employee.containsKey(EmpID)) {
				System.out.println(employee.get(EmpID).getFirst() + " " + employee.get(EmpID).getLast()
						+ ", has been clocked in.");
				employee.get(EmpID).setClockIn(new Date());
				System.out.println("Clocked in at: " + employee.get(EmpID).getClockIn());
			} else {
				System.out.println("Employee does not exist in database. Check employee ID and try again.");
			}
			// Clear after each click
			tfEmpID4.clear();
		});

		Button btDontClockIn = new Button("Go Back");
		btDontClockIn.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfEmpID4.clear();
			window.setScene(EmployeeStage);
			window.setTitle("Employee Database");
		});

		VBox ClockInlayout = new VBox(20);
		ClockInlayout.getChildren().addAll(EmpIDE4, tfEmpID4, btClockIn, btDontClockIn);
		ClockInE = new Scene(ClockInlayout, 300, 250);

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// ClockOutE
		Label EmpIDE5 = new Label("ID Number:");
		// Initialize Text Fields Employee
		TextField tfEmpID5 = new TextField();
		Button btClockOut = new Button("Clock Out");

		btClockOut.setOnAction(e -> {
			// Create new employee from user input
			String ID = tfEmpID5.getText();
			EmpID = Integer.parseInt(ID);
			if (employee.containsKey(EmpID)) {
				System.out.println(employee.get(EmpID).getFirst() + " " + employee.get(EmpID).getLast()
						+ ", has been clocked out.");
				employee.get(EmpID).setClockOut(new Date());
				System.out.println("Clocked out at: " + employee.get(EmpID).getClockOut());
			} else {
				System.out.println("Employee does not exist in database. Check employee ID and try again.");
			}
			// Clear after each click
			tfEmpID5.clear();
		});

		Button btDontClockOut = new Button("Go Back");
		btDontClockOut.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfEmpID5.clear();
			window.setScene(EmployeeStage);
			window.setTitle("Employee Database");
		});

		VBox ClockOutlayout = new VBox(20);
		ClockOutlayout.getChildren().addAll(EmpIDE5, tfEmpID5, btClockOut, btDontClockOut);
		ClockOutE = new Scene(ClockOutlayout, 300, 250);

		//////////////////////////////////////////////////////////////////////////////////////////////////
		// SearchE
		Label EmpIDE6 = new Label("ID Number:");
		// Initialize Text Fields Employee
		TextField tfEmpID6 = new TextField();

		Button btSearchEmployee = new Button("Search Database");
		btSearchEmployee.setOnAction(e -> {
			// Create new employee from user input
			String ID = tfEmpID6.getText();
			EmpID = Integer.parseInt(ID);
			if (employee.containsKey(EmpID)) {
				System.out.println(employee.get(EmpID).toString());
			} else {
				System.out.println("Specified employee ID does not exist within database.");
			}
			// Clear after each click
			tfEmpID6.clear();
		});

		Button btDontSearchEmployee = new Button("Go Back");
		btDontSearchEmployee.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfEmpID6.clear();
			window.setScene(EmployeeStage);
			window.setTitle("Employee Database");
		});

		VBox SearchElayout = new VBox(20);
		SearchElayout.getChildren().addAll(EmpIDE6, tfEmpID6, btSearchEmployee, btDontSearchEmployee);
		SearchE = new Scene(SearchElayout, 300, 250);

		////////////////////////////////////////////////////////////////////////////////////////////////
		// WageE
		Label EmpIDE7 = new Label("ID Number:");
		// Initialize Text Fields Employee
		TextField tfEmpID7 = new TextField();

		Button btWage = new Button("Calculate Wage");
		btWage.setOnAction(e -> {
			// Create new employee from user input
			String ID = tfEmpID7.getText();
			EmpID = Integer.parseInt(ID);
			if (employee.containsKey(EmpID) && employee.get(EmpID).getClockIn() != null
					&& employee.get(EmpID).getClockOut() != null) {
				// Set wage by subtracting clock-out by clock-in, convert milliseconds to hours,
				// multiply by rate
				employee.get(EmpID).setWage(employee.get(EmpID).CalculateWage());
				System.out.println("Potential wage based on time clock:\n$"
						+ String.format("%.2f", employee.get(EmpID).getWage()));
			}
			if (employee.containsKey(EmpID)
					&& (employee.get(EmpID).getClockIn() == null || employee.get(EmpID).getClockOut() == null)) {
				System.out
						.println("Employee needs to clock in and clock out before the system can process their wage.");
			} else {
				System.out.println("Specified Employee ID could not be found in the database.");
			}
			// Clear after each click
			tfEmpID7.clear();
		});

		Button btDontWage = new Button("Go Back");
		btDontWage.setOnAction(e -> {
			// Clear the textfields before calling the previous scene
			tfEmpID7.clear();
			window.setScene(EmployeeStage);
			window.setTitle("Employee Database");
		});

		VBox Wagelayout = new VBox(20);
		Wagelayout.getChildren().addAll(EmpIDE7, tfEmpID7, btWage, btDontWage);
		WageE = new Scene(Wagelayout, 300, 250);

		///////////////////////////////////////////////////////////////////////////////////////////////
		// Create a scene and place it on the stage
		primaryStage.setTitle("Main Menu"); // Set title
		primaryStage.setScene(MainStage); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}

	//
	// Main
	//
	public static void main(String[] args) {
		Application.launch(args);
	}
}
